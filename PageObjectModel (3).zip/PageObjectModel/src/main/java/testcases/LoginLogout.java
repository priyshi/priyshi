package testcases;

import java.util.Properties;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginLogout extends ProjectSpecificMethods{
	

	@Test
	public void runLogin() throws InterruptedException {
		System.out.println(driver);
		//first method action is available in the LoginPage
		LoginPage lp = new LoginPage(driver,prop);
		lp.enterUsername(prop.getProperty("username"))
		.enterPassword(prop.getProperty("password"))
		.clickLoginButton()
		.verifyHomePage();
		

	}
	
	@BeforeTest
	public void setValues() {
		// TODO Auto-generated method stub
		testName = "VerifyLogin";
		String testDescription = "Login with Positive Credentials";
		testAuthor= "Priya";
		testCategory="Smoke";

	}
	
	
}


