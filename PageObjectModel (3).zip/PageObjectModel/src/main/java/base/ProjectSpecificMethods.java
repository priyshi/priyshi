package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Utility.ReadExcel;
import io.github.bonigarcia.wdm.WebDriverManager;
import week8.day1.LearnExtentReport;

public class ProjectSpecificMethods {
	
	public ChromeDriver driver; //initial value will be null
	public static ExtentReports extent;
	public String testName, testDecription, testCategory, testAuthor;
	public static ExtentTest test;
	
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result2.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void setTestCaseDetails() {
	    test = extent.createTest(testName,testDecription);
		test.assignCategory(testCategory);
		test.assignAuthor(testAuthor);

	}
	
	@BeforeMethod
	public void preCondition() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(); // Driver is initialized 
		System.out.println(driver);
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}
	
	@AfterMethod
	public void postCondition1() {
		driver.close();

	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();

	}


//	public ChromeDriver driver; // initial value will be null
	public static String leadId;

	public String excelFileName;
	
	public Properties prop;

	@DataProvider(name = "fetchData",indices=0)
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(excelFileName); // CreateLead
	}

	@Parameters({"language"})
	@BeforeMethod
	public void preCondition(String lang) throws IOException {

		FileInputStream fis = new FileInputStream("./src/main/resources/"+lang+".properties");
		prop = new Properties();
		prop.load(fis);

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(); // Driver is initialized
		System.out.println(driver);
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
	
}
